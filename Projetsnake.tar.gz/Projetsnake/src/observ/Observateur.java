package observ;

public interface Observateur {
	public void actualiser(int turn, boolean finalStop);
}
