package observ;

import utils.AgentAction;

public interface ObservateurLastKey {
	public void updateLastKey(AgentAction lastKey);
}
