package view;

import javax.swing.JPanel;

public class PanelScore extends JPanel{
	
	private static final long serialVersionUID = 1L;

	public PanelScore() {
		this.setSize(100, 300);
	}

}
