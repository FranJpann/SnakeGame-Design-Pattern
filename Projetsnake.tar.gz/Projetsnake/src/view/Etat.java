package view;

public interface Etat {
	
	public void restart();
	public void play();
	public void pause();
	
}
