package utils;

public enum ColorSnake {
	Green,Red;
}
