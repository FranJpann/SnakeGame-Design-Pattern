package utils;

public enum AgentAction {
	MOVE_UP,MOVE_DOWN,MOVE_LEFT,MOVE_RIGHT
}
