package utils;


public enum ItemType {
	APPLE,BOX,SICK_BALL,INVINCIBILITY_BALL
}